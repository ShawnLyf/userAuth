from django.test import TestCase
from today.models import Tag




# c1 = Tag(name='shawn',tag = '高性价比')
# c1.save()
# print("")

# class Test(TestCase):
#     def check(self):
#         c1 = Tag(name='shawn',tag = '高性价比')
#         c1.save()

# t = Test()
# t.check()